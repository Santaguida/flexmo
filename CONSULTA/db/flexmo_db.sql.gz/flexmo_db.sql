-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 20-Mar-2015 às 18:26
-- Versão do servidor: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `flexmo_db`
--
CREATE DATABASE IF NOT EXISTS `flexmo_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `flexmo_db`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_user_name`
--

DROP TABLE IF EXISTS `tbl_user_name`;
CREATE TABLE IF NOT EXISTS `tbl_user_name` (
`id` int(10) unsigned NOT NULL COMMENT 'Id',
  `name` varchar(255) NOT NULL COMMENT 'First name',
  `last_name` varchar(255) NOT NULL COMMENT 'last name',
  `user_name` varchar(255) NOT NULL COMMENT 'keep the format to example',
  `phone_ext` smallint(6) DEFAULT NULL COMMENT 'Company phone extension (4 numbers)',
  `register` int(10) unsigned NOT NULL COMMENT 'employee register namber',
  `badge` int(10) unsigned DEFAULT NULL COMMENT 'employee badge namber',
  `home_phone` int(10) unsigned NOT NULL COMMENT 'Home phone',
  `molibe_phone` int(10) unsigned NOT NULL COMMENT 'Cellphone',
  `e-mail` varchar(255) NOT NULL COMMENT 'email',
  `home_adress` varchar(255) NOT NULL COMMENT 'street and number',
  `hood` varchar(255) NOT NULL COMMENT 'neighborhood',
  `city` varchar(255) NOT NULL COMMENT 'city',
  `password` varchar(255) NOT NULL COMMENT 'password encrypted',
  `occupation` varchar(255) NOT NULL COMMENT 'function in company',
  `shift` tinyint(3) unsigned NOT NULL COMMENT 'shift',
  `level_access` tinyint(3) unsigned DEFAULT NULL COMMENT 'level access'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbl_user_name`
--

INSERT INTO `tbl_user_name` (`id`, `name`, `last_name`, `user_name`, `phone_ext`, `register`, `badge`, `home_phone`, `molibe_phone`, `e-mail`, `home_adress`, `hood`, `city`, `password`, `occupation`, `shift`, `level_access`) VALUES
(4, 'Fernando', 'Santaguida', 'saofsant', 3782, 123456, 147852, 0, 0, 'santaguidafernando@gmail.com', 'Rua JosÃ© Hannickel, 234', 'Vila Nicanor Marques', 'Sorocaba SP', '4c5361db91fa8bd389639e0b147e2c5dfda635f668e2379987e029f5b55f76d1e71c0f8f4d98faf183a7222f54a2d1889d9176d09dd5308074c2a231e1578bc6', 'tecnico', 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_user_name`
--
ALTER TABLE `tbl_user_name`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_user_name`
--
ALTER TABLE `tbl_user_name`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id',AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
