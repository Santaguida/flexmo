-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 20-Maio-2015 às 13:36
-- Versão do servidor: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `flexmo_db`
--
CREATE DATABASE IF NOT EXISTS `flexmo_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `flexmo_db`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_fct_jigs`
--

DROP TABLE IF EXISTS `tbl_fct_jigs`;
CREATE TABLE IF NOT EXISTS `tbl_fct_jigs` (
`id` int(10) unsigned NOT NULL,
  `product` int(10) unsigned NOT NULL,
  `jigid` varchar(10) NOT NULL,
  `jigQnt` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbl_fct_jigs`
--

INSERT INTO `tbl_fct_jigs` (`id`, `product`, `jigid`, `jigQnt`) VALUES
(3, 2, 'HPN', 30);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_fct_parts`
--

DROP TABLE IF EXISTS `tbl_fct_parts`;
CREATE TABLE IF NOT EXISTS `tbl_fct_parts` (
`id` int(10) unsigned NOT NULL,
  `product` int(10) unsigned NOT NULL,
  `code` varchar(50) NOT NULL,
  `descr` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbl_fct_parts`
--

INSERT INTO `tbl_fct_parts` (`id`, `product`, `code`, `descr`) VALUES
(1, 2, 'FXHP10025879', 'PeÃ§a de teste do sistema');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_fct_problem`
--

DROP TABLE IF EXISTS `tbl_fct_problem`;
CREATE TABLE IF NOT EXISTS `tbl_fct_problem` (
`id` int(10) unsigned NOT NULL,
  `problem` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbl_fct_problem`
--

INSERT INTO `tbl_fct_problem` (`id`, `problem`) VALUES
(4, '4- 4- 4- HD corrompido'),
(5, 'cabelo solto');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_fct_jigs`
--
ALTER TABLE `tbl_fct_jigs`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fct_parts`
--
ALTER TABLE `tbl_fct_parts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fct_problem`
--
ALTER TABLE `tbl_fct_problem`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_fct_jigs`
--
ALTER TABLE `tbl_fct_jigs`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_fct_parts`
--
ALTER TABLE `tbl_fct_parts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_fct_problem`
--
ALTER TABLE `tbl_fct_problem`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
