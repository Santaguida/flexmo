-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 27-Mar-2015 às 11:50
-- Versão do servidor: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `flexmo_db`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_users`
--
-- Criação: 27-Mar-2015 às 10:33
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE IF NOT EXISTS `tbl_users` (
`id` int(10) unsigned NOT NULL COMMENT 'Id',
  `name` varchar(255) NOT NULL COMMENT 'First name',
  `last_name` varchar(255) NOT NULL COMMENT 'last name',
  `user_name` varchar(255) NOT NULL COMMENT 'keep the format to example',
  `phone_ext` smallint(6) DEFAULT NULL COMMENT 'Company phone extension (4 numbers)',
  `register` int(10) unsigned NOT NULL COMMENT 'employee register namber',
  `badge` int(10) unsigned DEFAULT NULL COMMENT 'employee badge namber',
  `home_phone` int(10) unsigned NOT NULL COMMENT 'Home phone',
  `molibe_phone` bigint(11) unsigned NOT NULL COMMENT 'Cellphone',
  `e-mail` varchar(255) NOT NULL COMMENT 'email',
  `home_adress` varchar(255) NOT NULL COMMENT 'street and number',
  `neighborhood` varchar(255) NOT NULL COMMENT 'neighborhood',
  `city` varchar(255) NOT NULL COMMENT 'city',
  `password` varchar(255) NOT NULL COMMENT 'password encrypted',
  `occupation` varchar(255) NOT NULL COMMENT 'function in company',
  `shift` tinyint(3) unsigned NOT NULL COMMENT 'shift',
  `level_access` tinyint(3) unsigned NOT NULL DEFAULT '4' COMMENT 'level access',
  `enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `name`, `last_name`, `user_name`, `phone_ext`, `register`, `badge`, `home_phone`, `molibe_phone`, `e-mail`, `home_adress`, `neighborhood`, `city`, `password`, `occupation`, `shift`, `level_access`, `enabled`) VALUES
(2, 'Gabriel', 'Nazato', 'saognaza', 6842, 19897, 43893, 1532330653, 15991252732, 'Gabriel.Nazato@Flextronics.com', 'Rua Galileu Pasquinelli 1004, comp. 06', 'Vila Fiori', 'Sorocaba', '006661d40bec467b3d66b9eae6701f55b9eb6cf4bdfb3b210ed2ab9c595dbcf5653a4edbda4b9f5cd2f456274fc0c7f76f0f5dc186f27288e89aebe65eccc858', 'engenheiro', 4, 4, 1),
(3, 'Fernando Henrique', 'Santaguida', 'saofsant', 3782, 20458, 65675, 1533183050, 15996408034, 'fernando.santaguida@flextronics.com', 'Rua JosÃ© Hannickel, 234', 'Vila Nicanor Marques', 'Sorocaba SP', '006661d40bec467b3d66b9eae6701f55b9eb6cf4bdfb3b210ed2ab9c595dbcf5653a4edbda4b9f5cd2f456274fc0c7f76f0f5dc186f27288e89aebe65eccc858', 'tecnico', 1, 4, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id',AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
